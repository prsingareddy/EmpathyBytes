//
//  testApp.swift
//  test
//
//  Created by Pranathi Singareddy on 10/3/20.
//

import SwiftUI

@main
struct testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
